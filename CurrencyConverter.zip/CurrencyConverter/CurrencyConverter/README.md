
TODOs:

Complete the following tasks:
1. Extract all the strings into the **strings.xml** file and use them in the layout and the activity
2. Add **ViewBinding** to the project
